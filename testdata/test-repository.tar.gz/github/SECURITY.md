# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| >= 4.x  | :white_check_mark: |
| < 4.0   | :x:                |

## Reporting a Vulnerability

Please send the details to:

- Matthew Holt <matt at dyanim dot com>